package coach;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;




public class Demo {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(SportsConfig.class);
        Coach coach = context.getBean("myCricketCoach", Coach.class);
        System.out.println(coach.getDailyWorkOut());
        System.out.println(coach.getDailyWish());
        System.out.println(coach.getEmailAddress());
        context.close();
    }
}
