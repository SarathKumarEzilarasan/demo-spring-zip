package coach;

import org.springframework.context.annotation.*;

@Configuration
@ComponentScan("coach")
@PropertySource("sports.properties")
public class SportsConfig {

    @Bean
    public Coach swimCoach() {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(SportsConfig.class);
        HappyWishService happyWishService = context.getBean("happyWishService",HappyWishService.class);
        return new SwimCoach(happyWishService);
    }
}
