package coach;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@Component("myCricketCoach")
public class CricketCoach implements Coach {
    //dependency injection
    @Autowired
    @Qualifier("happyWishService")
    private WishService wishService; // what is reflection??????
    @Value("${foo.email}")
    private String emailAddress;

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    //    @Autowired
//    public CricketCoach(WishService wishService) {
//        this.wishService = wishService;
//    }
//    @Autowired
//    public void setWishService(WishService wishService) {
//        this.wishService = wishService;
//    }


    public String getDailyWorkOut() {
        return "30 mins batting practice";
    }

    public String getDailyWish() {
        return wishService.getDailyWish();
    }

    @PostConstruct
    public void startUpMethod() {
        System.out.println("started");
    }

    @PreDestroy
    public void destroyMethod() {
        System.out.println("destroyed");
    }

}
