package coach;

import org.springframework.stereotype.Component;

@Component
public class MotivateWishService implements WishService {
    @Override
    public String getDailyWish() {
        return "Good luck for the next match";
    }
}
