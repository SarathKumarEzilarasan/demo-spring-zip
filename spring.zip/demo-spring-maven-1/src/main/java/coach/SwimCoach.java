package coach;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;


public class SwimCoach implements Coach {
    //dependency injection
    private WishService wishService; // what is reflection??????

    public SwimCoach(WishService wishService) {
        this.wishService = wishService;
    }


    public String getDailyWorkOut() {
        return "30 mins swimming practice";
    }

    public String getDailyWish() {
        return wishService.getDailyWish();
    }

    @Override
    public String getEmailAddress() {
        return null;
    }

}
