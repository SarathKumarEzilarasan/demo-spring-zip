package coach;

public class FootBallCoach implements Coach {
    //dependency injection
    private WishService wishService;

    public FootBallCoach(WishService wishService) {
        this.wishService = wishService;
    }

    public String getDailyWorkOut() {
        return "30 mins kicking practice";
    }

    public String getDailyWish() {
        return wishService.getDailyWish();
    }

    @Override
    public String getEmailAddress() {
        return null;
    }
}
