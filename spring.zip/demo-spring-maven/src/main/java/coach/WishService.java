package coach;

public interface WishService {
    String getDailyWish();
}
