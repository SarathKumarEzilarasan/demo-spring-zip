package coach;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Demo {
    public static void main(String[] args) {
        //Tight coupling -> lose coupling

//        CricketCoach cricketCoach = new CricketCoach();
//        System.out.println(cricketCoach.getDailyWorkOut());

//        FootBallCoach footBallCoach = new FootBallCoach();
//        System.out.println(footBallCoach.getDailyWorkOut());

//        // partially lose coupled
//        Coach coach = new CricketCoach(new HappyWishService());
//        System.out.println(coach.getDailyWorkOut());


        ClassPathXmlApplicationContext context =
                new ClassPathXmlApplicationContext("config.xml");
        Coach coach1 = context.getBean("myCricketCoach", Coach.class);
//        Coach coach2 = context.getBean("myCricketCoach", Coach.class);

//        System.out.println(coach1);
//        System.out.println(coach2);



        context.close();

    }
}
