package coach;

public interface Coach {
    String getDailyWorkOut();
    String getDailyWish();
    String getEmailAddress();
}
