package coach;

public class CricketCoach implements Coach {
    //dependency injection
    private WishService wishService;
    private String emailAddress;

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    //    public CricketCoach(WishService wishService) {
//        this.wishService = wishService;
//    }

    public void setWishService(WishService wishService){
        this.wishService = wishService;
    }


    public String getDailyWorkOut() {
        return "30 mins batting practice";
    }

    public String getDailyWish() {
        return wishService.getDailyWish();
    }


    public void startUpMethod(){
        System.out.println("started");
    }

    public void destroyMethod(){
        System.out.println("destroyed");
    }

}
