package coach;

public class HappyWishService implements WishService {
    @Override
    public String getDailyWish() {
        return "Good luck for the next match";
    }
}
